<?php
 $db = mysqli_connect('sql213.epizy.com', 'epiz_28886546', 'vfSKSFrR5DQAI') or
        die ('Unable to connect. Check your connection parameters.');
        mysqli_select_db($db, 'epiz_28886546_cruddb' ) or die(mysqli_error($db));
?>